import React from "react";

import "./App.css";
import FormInput from "./components/FormInput/FormInput";
import Output from "./components/Output/Output";

function App() {
  return (
    <div className="App">
      {/* <FormInput /> */}
      <Output />
    </div>
  );
}

export default App;
