import React, { useEffect, useState } from "react";
import { Container } from "react-bootstrap";
import { useForm } from "react-hook-form";
import axios from "axios";

import { Modal, Button } from "react-bootstrap";

import "./FormInput.scss";

function FormInput() {
  const [output, setOutput] = useState([]);

  const outputTitle = [
    "Tarifa Azul",
    "Tarifa Verde",
    "ACL Convencional",
    "ACL I0",
    "ACL CG5",
    "ACL I5",
    "ACL I1",
    "Tarifa Branca",
    "Tarifa Convencional",
    "GD Autoconsumo",
    "GD Compartilhada",
  ];

  useEffect(() => {
    const data = {
      distribuidora: "EMT",
      modalidade: "Azul",
      classe: "NÃ£o se aplica",
      tensao: "A4",
      fase: "TRIFASICO",
      demanda_fora_ponta_kw: 592,
      demanda_ponta_kw: 584,
      consumo_medio_fp_mwh: 360.394,
      consumo_medio_p_mwh: 34.041,
      icms: 0.3,
      pis: 0.0155,
      cofins: 0.0715,
    };
    // "Energy-Simulator-Auth": "93906abd-5573-4f82-935e-d37490362306",

    axios
      .post(
        "https://cors-anywhere.herokuapp.com/http://ec2-54-207-233-11.sa-east-1.compute.amazonaws.com:8081/api/energy/calculation",
        data,
        {
          headers: {
            "Energy-Simulator-Auth": "93906abd-5573-4f82-935e-d37490362306",
          },
        }
      )
      .then((res) => {
        console.log(res, res.data.energyCalculations[0].brl_mwh);
        setOutput(res.data.energyCalculations);
      })
      .catch((err) => console.log(err));
  }, []);
  console.log("output", output);
  return (
    <>
      <div className="mainWraper">
        <div class="container">
          <div className="innerContainer">
            <div className="mainTitleWraper">
              <p className="mainTitle">Simulador de Energia</p>
            </div>

            <div class="row">
              {output.length > 0 &&
                output.map((data, i) => {
                  return (
                    <div class="col-xs-12 col-sm-6 col-lg-3">
                      <a class="card1" href="#">
                        <h3>{outputTitle[i]}</h3>
                        <span>Você vai pagar:</span>
                        <p class="big">{Number(data.brl_mwh).toFixed(3)}</p>
                        <p className="small">R$/MWh</p>
                        <div class="go-corner" href="#">
                          <div class="go-arrow">→</div>
                        </div>
                      </a>
                    </div>
                  );
                })}

              {/* <a class="card1" href="#">
              <h3>This is option 1</h3>
              <p class="small">
                Card description with lots of great facts and interesting
                details.
              </p>
              <div class="go-corner" href="#">
                <div class="go-arrow">→</div>
              </div>
            </a>
            <a class="card1" href="#">
              <h3>This is option 1</h3>
              <p class="small">
                Card description with lots of great facts and interesting
                details.
              </p>
              <div class="go-corner" href="#">
                <div class="go-arrow">→</div>
              </div>
            </a>
            <a class="card1" href="#">
              <h3>This is option 1</h3>
              <p class="small">
                Card description with lots of great facts and interesting
                details.
              </p>
              <div class="go-corner" href="#">
                <div class="go-arrow">→</div>
              </div>
            </a>
            <a class="card1" href="#">
              <h3>This is option 1</h3>
              <p class="small">
                Card description with lots of great facts and interesting
                details.
              </p>
              <div class="go-corner" href="#">
                <div class="go-arrow">→</div>
              </div>
            </a>
            <a class="card1" href="#">
              <h3>This is option 1</h3>
              <p class="small">
                Card description with lots of great facts and interesting
                details.
              </p>
              <div class="go-corner" href="#">
                <div class="go-arrow">→</div>
              </div>
            </a>
            <a class="card1" href="#">
              <h3>This is option 1</h3>
              <p class="small">
                Card description with lots of great facts and interesting
                details.
              </p>
              <div class="go-corner" href="#">
                <div class="go-arrow">→</div>
              </div>
            </a>
            <a class="card1" href="#">
              <h3>This is option 1</h3>
              <p class="small">
                Card description with lots of great facts and interesting
                details.
              </p>
              <div class="go-corner" href="#">
                <div class="go-arrow">→</div>
              </div>
            </a>
            <a class="card1" href="#">
              <h3>This is option 1</h3>
              <p class="small">
                Card description with lots of great facts and interesting
                details.
              </p>
              <div class="go-corner" href="#">
                <div class="go-arrow">→</div>
              </div>
            </a>
            <a class="card1" href="#">
              <h3>This is option 1</h3>
              <p class="small">
                Card description with lots of great facts and interesting
                details.
              </p>
              <div class="go-corner" href="#">
                <div class="go-arrow">→</div>
              </div>
            </a> */}
            </div>
            <div className="infoWraper">
              <div className="infoTitle">
                <p className="title">Informações:</p>
                <p className="info">
                  Os valores e os consumos apurados são apenas uma estimativa
                  realizada com base nas informações cadastradas no simulador,
                  não serão utilizadas para o faturamento de sua unidade
                  consumidora.
                </p>
                <p className="info">
                  Tarifa utilizada considerando a aplicação dos tributos: ICMS,
                  PIS/PASEP e COFINS.
                </p>
                <p className="info">
                  Nesta simulação não estão sendo considerados os valores das
                  bandeiras tarifárias.
                </p>
                <p className="title">Mercado Livre</p>
                <p className="info">
                  Esta é uma estimativa dos valores que considera os preços
                  médios de energia no mercado livre.
                </p>
                <p className="info">
                  Estão aptos ao ML aqueles que possuem uma demanda superior a
                  500 kW ou mais de um estabelecimento onde a soma da demanda
                  contratada alcançar 500 kW
                </p>
                <p className="info">
                  Clientes com demanda inferior a 2.000 kW necessitam contratar
                  energia incentivada.
                </p>
                <p className="title">Geração Distribuída</p>
                <p className="info">
                  Valores podem variar de acordo com potência instalada da usina
                  escolhida
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}

export default FormInput;
