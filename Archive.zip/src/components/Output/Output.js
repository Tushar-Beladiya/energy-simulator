import React, { useState } from "react";
import "./Output.css";
import { useForm } from "react-hook-form";
import { useHistory } from "react-router-dom";

function Output() {
  const { handleSubmit, register, errors } = useForm();
  const [userName, setUserName] = useState("");
  const [userEmail, setUserEmail] = useState("");

  let history = useHistory();
  const [show, setShow] = useState(false);

  const onCloseBtnHandler = () => {
    setShow(false);
  };

  const handleClose = () => {
    var mailformat = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/;
    if (userName && userEmail && userEmail.match(mailformat)) {
      setShow(false);
    }
    history.push("/output");
  };

  const handleShow = () => setShow(true);
  return (
    <div>
      <div class="section_main">
        <div class="container">
          <div class="row">
            <div class="col-md-12 heading_text">
              <div class="detail">
                <img src="img/new.webp" class="img-fluid mobile_img" />
                <h2>Energy Simulator</h2>
                <p>
                  Compare rates between Free Market, Regulated Market and
                  Distributed Generation. See how to save by joining the best
                  tariff modality for your consumer unit!
                </p>
              </div>
              <div class="form_fix">
                <p class="form_fix_title">
                  Fill in the details and see what is the best rate for you
                </p>
                <div class="section_dropdown">
                  <div class="dropdown  dropdown_box">
                    {/* <a
                      class="btn dropdown-toggle"
                      href="#"
                      role="button"
                      id="dropdownMenuLink"
                      data-toggle="dropdown"
                      aria-haspopup="true"
                      aria-expanded="false"
                    >
                      Distributor
                      <i class="fa fa-angle-down" aria-hidden="true"></i>
                    </a>
                    <div
                      class="dropdown-menu"
                      aria-labelledby="dropdownMenuLink"
                    >
                      <a class="dropdown-item" href="#">
                        Distributor
                      </a>
                      <a class="dropdown-item" href="#">
                        Distributor
                      </a>
                      <a class="dropdown-item" href="#">
                        Distributor
                      </a>
                    </div> */}
                  </div>

                  <select
                    className="btn dropdown-toggle"
                    id="dropdownMenuLink"
                    name="distribuidora"
                    ref={register({
                      required: "Distribuidora is missing",
                    })}
                  >
                    <option>Distribuidora</option>
                    <option value="AME">AME</option>
                    <option value="Boa Vista">Boa Vista</option>
                    <option value="CASTRO - DIS">CASTRO - DIS</option>
                    <option value="CEA">CEA</option>
                    <option value="CEBDIS">CEBDIS</option>
                    <option value="CEDRAP">CEDRAP</option>
                    <option value="CEDRI">CEDRI</option>
                    <option value="CEEE-D">CEEE-D</option>
                    <option value="CEGERO">CEGERO</option>
                    <option value="CEJAMA">CEJAMA</option>
                    <option value="CELG-D">CELG-D</option>
                    <option value="CELPE">CELPE</option>
                    <option value="CEMAR">CEMAR</option>
                    <option value="CEMIG-D">CEMIG-D</option>
                    <option value="CEMIRIM">CEMIRIM</option>
                    <option value="CEPRAG">CEPRAG</option>
                    <option value="CERAÇÁ">CERAÇÁ</option>
                    <option value="CERAL">CERAL</option>
                    <option value="CERAL DIS">CERAL DIS</option>
                    <option value="CERBRANORTE">CERBRANORTE</option>
                    <option value="CERCI">CERCI</option>
                    <option value="CERCOS">CERCOS</option>
                    <option value="CEREJ">CEREJ</option>
                    <option value="CERES">CERES</option>
                    <option value="CERFOX">CERFOX</option>
                    <option value="CERGAL">CERGAL</option>
                    <option value="CERGAPA">CERGAPA</option>
                    <option value="CERGRAL">CERGRAL</option>
                    <option value="CERILUZ">CERILUZ</option>
                    <option value="CERIM">CERIM</option>
                    <option value="CERIPA">CERIPA</option>
                    <option value="CERIS">CERIS</option>
                    <option value="CERMC">CERMC</option>
                    <option value="CERMISSÕES">CERMISSÕES</option>
                    <option value="CERMOFUL">CERMOFUL</option>
                    <option value="CERNHE">CERNHE</option>
                    <option value="CERON">CERON</option>
                    <option value="CERPALO">CERPALO</option>
                    <option value="CERPRO">CERPRO</option>
                    <option value="CERRP">CERRP</option>
                    <option value="CERSAD DISTRIBUIDORA">
                      CERSAD DISTRIBUIDORA
                    </option>
                    <option value="CERSUL">CERSUL</option>
                    <option value="CERTAJA">CERTAJA</option>
                    <option value="CERTEL">CERTEL</option>
                    <option value="CERTHIL">CERTHIL</option>
                    <option value="CERTREL">CERTREL</option>
                    <option value="CERVAM">CERVAM</option>
                    <option value="CETRIL">CETRIL</option>
                    <option value="CHESP">CHESP</option>
                    <option value="COCEL">COCEL</option>
                    <option value="CODESAM">CODESAM</option>
                    <option value="COELBA">COELBA</option>
                    <option value="COOPERA">COOPERA</option>
                    <option value="COOPERALIANÇA">COOPERALIANÇA</option>
                    <option value="COOPERCOCAL">COOPERCOCAL</option>
                    <option value="COOPERLUZ">COOPERLUZ</option>
                    <option value="COOPERNORTE">COOPERNORTE</option>
                    <option value="COOPERSUL">COOPERSUL</option>
                    <option value="COOPERZEM">COOPERZEM</option>
                    <option value="COORSEL">COORSEL</option>
                    <option value="COPEL-DIS">COPEL-DIS</option>
                    <option value="COPREL">COPREL</option>
                    <option value="COSERN">COSERN</option>
                    <option value="CPFL Jaguari">CPFL Jaguari</option>
                    <option value="CPFL Leste Paulista">
                      CPFL Leste Paulista
                    </option>
                    <option value="CPFL Mococa">CPFL Mococa</option>
                    <option value="CPFL- PIRATININGA">CPFL- PIRATININGA</option>
                    <option value="CPFL Santa Cruz">CPFL Santa Cruz</option>
                    <option value="CPFL Sul Paulista">CPFL Sul Paulista</option>
                    <option value="CPFL-PAULISTA">CPFL-PAULISTA</option>
                    <option value="CRELUZ-D">CRELUZ-D</option>
                    <option value="CRERAL">CRERAL</option>
                    <option value="DCELT">DCELT</option>
                    <option value="DEMEI">DEMEI</option>
                    <option value="DMED">DMED</option>
                    <option value="EBO">EBO</option>
                    <option value="EDP SP">EDP SP</option>
                    <option value="EFLJC">EFLJC</option>
                    <option value="EFLUL">EFLUL</option>
                    <option value="ELEKTRO">ELEKTRO</option>
                    <option value="ELETROACRE">ELETROACRE</option>
                    <option value="ELETROCAR">ELETROCAR</option>
                    <option value="ELETROPAULO">ELETROPAULO</option>
                    <option value="ELFSM">ELFSM</option>
                    <option value="EMS">EMS</option>
                    <option value="EMT">EMT</option>
                    <option value="ENEL CE">ENEL CE</option>
                    <option value="ENEL RJ">ENEL RJ</option>
                    <option value="EPB">EPB</option>
                    <option value="Equatorial AL">Equatorial AL</option>
                    <option value="Equatorial PA">Equatorial PA</option>
                    <option value="Equatorial PI">Equatorial PI</option>
                    <option value="ESE">ESE</option>
                    <option value="ESS">ESS</option>
                    <option value="ETO">ETO</option>
                    <option value="FORCEL">FORCEL</option>
                    <option value="HIDROPAN">HIDROPAN</option>
                    <option value="LIGHT">LIGHT</option>
                    <option value="MUXENERGIA">MUXENERGIA</option>
                    <option value="RGE SUL">RGE SUL</option>
                    <option value="SULGIPE">SULGIPE</option>
                  </select>
                  <div class="dropdown  dropdown_box">
                    <select
                      className="btn dropdown-toggle"
                      id="dropdownMenuLink"
                      name="modalidade"
                      ref={register({
                        required: "Modalidade is missing",
                      })}
                    >
                      <option value="">Modalidade </option>
                      <option value="Azul">Azul</option>
                      <option value="Convencional">Convencional</option>
                      <option value="Verde">Verde</option>
                      <option value="Branca">Branca</option>
                    </select>
                  </div>
                  <div class="dropdown  dropdown_box">
                    <select
                      className="btn dropdown-toggle"
                      id="dropdownMenuLink"
                      name="classe"
                      ref={register({
                        required: "Classe is missing",
                      })}
                    >
                      <option value="">classe </option>
                      <option value="Não se aplica">Não se aplica</option>
                      <option value="Residencial">Residencial</option>
                      <option value="Rural">Rural</option>
                      <option value="Iluminação pública">
                        Iluminação pública
                      </option>
                    </select>
                  </div>
                  <div class="dropdown  dropdown_box"></div>
                  <div class="dropdown dropdown_box">
                    <select
                      className="btn dropdown-toggle"
                      id="dropdownMenuLink"
                      name="tensao"
                      ref={register({
                        required: "Tensão is missing",
                      })}
                    >
                      <option value="">Tensão </option>
                      <option value="A1">A1</option>
                      <option value="A2">A2</option>
                      <option value="A3">A3</option>
                      <option value="A3a">A3a</option>
                      <option value="A4">A4</option>
                      <option value="As">As</option>
                      <option value="B1">B1</option>
                      <option value="B2">B2</option>
                      <option value="B3">B3</option>
                      <option value="B4">B4</option>
                    </select>
                  </div>
                  <div class="dropdown  dropdown_box">
                    <select
                      className="btn dropdown-toggle"
                      id="dropdownMenuLink"
                      name="fase"
                      ref={register({
                        required: "Fase is missing",
                      })}
                    >
                      <option value="">Please Select Fase</option>
                      <option value="MONOFASICO">MONOFASICO</option>
                      <option value="BIFASICO">BIFASICO</option>
                      <option value="TRIFASICO">TRIFASICO</option>
                    </select>
                  </div>
                </div>
                <div class="input_field">
                  <div class="feild_box">
                    <input
                      type="text"
                      name="demanda_fora_ponta_kw"
                      ref={register({
                        required: "Demanda Fora Ponta is missing",
                      })}
                    />
                    <label>Demanda Fora Ponta (kW)</label>
                  </div>
                  <div class="feild_box">
                    <input
                      type="text"
                      defaultValue={0}
                      name="demanda_ponta_kw"
                      ref={register({
                        required: "Demanda Ponta is missing",
                      })}
                    />
                    <label>Demanda Ponta (kW)</label>
                  </div>
                  <div class="feild_box">
                    <input
                      type="text"
                      name="consumo_medio_fp_mwh"
                      defaultValue={0}
                      ref={register({
                        required: "Consumo Fora Ponta is missing",
                      })}
                    />
                    <label>Consumo Fora Ponta (kWh)</label>
                  </div>
                  <div class="feild_box">
                    <input
                      type="text"
                      name="consumo_medio_p_mwh"
                      defaultValue={0}
                      ref={register({
                        required: "Consumo Ponta is missing",
                      })}
                    />
                    <label>Consumo Ponta (kWh)</label>
                  </div>
                </div>
                <div class="second_feild">
                  <div class="feild_box">
                    <input
                      type="text"
                      name="icms"
                      ref={register({
                        required: "ICMS is missing",
                      })}
                    />
                    <label>Icms</label>
                  </div>
                  <div class="feild_box">
                    <input
                      type="text"
                      name="pis"
                      defaultValue={1}
                      ref={register({
                        required: "Pis is missing",
                      })}
                    />
                    <label>PIS</label>
                  </div>
                  <div class="feild_box">
                    <input
                      type="text"
                      name="cofins"
                      id="cofins"
                      defaultValue={5}
                      ref={register({
                        required: "cofins is missing",
                      })}
                    />
                    <label>COFINS</label>
                  </div>
                </div>
                <div class="simulation">
                  <button>Simulação</button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Output;
